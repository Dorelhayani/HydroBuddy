-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hydrobuddydb
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `esp_device_state`
--

DROP TABLE IF EXISTS `esp_device_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `esp_device_state` (
  `device_id` int unsigned NOT NULL,
  `doc` json NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state_int` int GENERATED ALWAYS AS (json_extract(`doc`,_utf8mb4'$.state')) STORED,
  `pump_status` tinyint(1) DEFAULT NULL,
  `pump_status_updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`device_id`),
  UNIQUE KEY `ux_device_id` (`device_id`),
  KEY `idx_state` (`state_int`),
  CONSTRAINT `fk_state_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `esp_device_state`
--

LOCK TABLES `esp_device_state` WRITE;
/*!40000 ALTER TABLE `esp_device_state` DISABLE KEYS */;
INSERT INTO `esp_device_state` (`device_id`, `doc`, `updated_at`, `pump_status`, `pump_status_updatedAt`) VALUES (1,'{\"pump\": {\"on\": false, \"updatedAt\": \"2025-11-17T21:19:14.996Z\"}, \"state\": 61, \"TEMP_MODE\": {\"temp\": 26.3, \"light\": 24, \"runMin\": 3, \"cooldown\": 15, \"lightGate\": 20, \"hysteresis\": 1, \"tempTarget\": 32, \"daylightOnly\": false}, \"MANUAL_MODE\": {\"enabled\": false}, \"SATURDAY_MODE\": {\"dateAct\": \"12/11/2025\", \"timeAct\": \"00:59\", \"duration\": 1}, \"SOIL_MOISTURE_MODE\": {\"light\": 0, \"runMin\": 3, \"cooldown\": 15, \"moisture\": 13, \"lightGate\": 30, \"hysteresis\": 1, \"daylightOnly\": false, \"moistureTarget\": 1}}','2025-11-17 21:32:36',0,'2025-11-17 23:32:36');
/*!40000 ALTER TABLE `esp_device_state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-17 23:32:37
