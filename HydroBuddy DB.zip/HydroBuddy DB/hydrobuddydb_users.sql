-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hydrobuddydb
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `current_token` varchar(512) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `avatar_url` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'dor','dori@email.com','1234',NULL,'2025-08-17',NULL),(2,'noy','noy@email.com','1234',NULL,'2025-08-22',NULL),(3,'carmela','carmela@email.com','7890',NULL,'2025-08-22',NULL),(4,'yarden','yarden@email.com','1234',NULL,'2025-08-22',NULL),(8,'viktor','viktor@email.com','1234',NULL,'2025-09-13',NULL),(9,'a','a@email.com','1234',NULL,'2025-09-24',NULL),(10,'b','b@email.com','1234',NULL,'2025-09-26',NULL),(11,'c','c@email.com','1234',NULL,'2025-09-26',NULL),(12,'d','d@email.com','$2b$08$6B6JifmWXdhyckoSjPd98.46gJsASjJHXRMgNUXlbXxn5cxL7Sqeu',NULL,'2025-09-26',NULL),(13,'e','e@email.com','$2b$08$rtWjcm2LoniZDpGr/UMVgOj9Clz2ucerX//I5p5AucT3hmKPCYqMS',NULL,'2025-09-26',NULL),(14,'f','@email.com','$2b$08$1zx72SyFfnxYFgeVI4VV3uKTstnetF3zpRgdg1DQQxYX/sEd5SnOe',NULL,'2025-09-26',NULL),(15,'g','@@email.com','$2b$08$9UcEWcgUQ1e.wxhOYA0Wi.qw9t2HkgloBVABUZRnQ6QTc8zTQ50ma',NULL,'2025-09-26',NULL),(16,'asd','!@email.com','$2b$08$ShBUZIWlHqhA1fo0HLNgu.J1r.1GoNxRV7zVSFbOVAA8GIL2InG1m',NULL,'2025-09-26',NULL),(17,'awe','#@email.om','$2b$08$C1irW9n3Fu/swM9IhGlpk.EHQj.r.h51abTKAjfWzm3/RwmI//sjO',NULL,'2025-09-26',NULL),(18,'sdf','@!@email.com','$2b$08$HbZBuye4F21RD3k8VTvx6OCHXIhXtlAnN1G1F2rwd7pGup64j62LC',NULL,'2025-09-26',NULL),(19,'qw','@@@@','$2b$08$GNS91KLOPKbeksbaxMukx.JZ5ZfOwnljmrrIqp27slIxJUpJRM.Na',NULL,'2025-09-26',NULL),(20,'bb','bb@email.com','$2b$08$/EJxYEF0MqxqEjCWkb5HpeYLtfIxuh3pbPdXWnpaTZlZXlqYdvTAa',NULL,'2025-09-26',NULL),(21,'sa','sa@email.com','$2b$08$sMCTv9aTzudg1Gmg2oxz/OTmU1ASFNWKVcz8/f7ezoLxg.5NxhBRG',NULL,'2025-09-26',NULL),(22,'sa','.!@email.com','$2b$08$K4A7lhlysgAm8LOkYU1Y0.pj7w6j1gxG1qZu8vpw1Sl9W5d3z7X46',NULL,'2025-09-26',NULL),(23,'sd','@@@!@','$2b$08$tzp7R3HVW8gw/T5jWUglouzXfjTKpMUwxeyckSBC5b56VKSlXwjc.',NULL,'2025-09-26',NULL),(24,'s','s@email.com','$2b$08$3esEvKRsSZX06hiyTE8DO.HlH9CrXHTIYxWdZAgH9lHkJslWKWXja',NULL,'2025-09-26',NULL),(25,'a','abc@email.com ','$2b$10$ASlOXKwGvz8PmQ/OMnvpLu4R9iR9m1Cv92ziRPSOv2SggBXic2PSW',NULL,'2025-09-26',NULL),(26,'dori','doridori@email.com','$2b$10$Fe8dGUKG85AUrl0qhBlO5.HdK4ZgynxRpZGb3i9s3aGJwuPxTZqv6',NULL,'2025-09-26','/uploads/avatars/26.png'),(27,'vik','vik@email.com','$2b$10$Xr36Jzwzj3GF9.troxed6e.ZVaFD4/k6AePMZBM0lc8UyDKbRFeoW',NULL,'2025-09-27',NULL),(28,'viktor','viktorel@email.com','$2b$10$oiLFyAKAOsFc5azTVeV26eWROlEaLVgfH2rH0EIdWHvbHybn.x4H6',NULL,'2025-09-27',NULL),(29,'viktor','viktorelhayani@email.com','$2b$10$EB74vYyMOSUKNSRnKCjEWeeguLDRsr7pxOAGD8PX0nEZne0yVarPe',NULL,'2025-09-27',NULL),(30,'EL','elhayani@email.com','$2b$10$WUe6T1xgtT5OFkPgDFN9oucITcd5SBkpmp/0sarFsuTdaC479Rn0.',NULL,'2025-09-27',NULL),(31,'efg','efg@email.com','$2b$10$MisUyJniUBmVcBKNxq1I/uh7666I8Q87FjLg7JWIf37pZyDPGgxKC',NULL,'2025-09-27',NULL),(32,'lolo','lolo@email.com','$2b$10$oZvtbB45PNJWcKQV/H9pXelkyGSwtDXPbAQnWcKgfcYn5QIFDbSra',NULL,'2025-09-28',NULL),(34,'meme','meme@email.com','$2b$10$Bg1ydjXuyV2Cz2NhaQY.n.2gxPUb2h7OPtg1.umy3HBQnmcvaCM.O',NULL,'2025-10-05',NULL),(35,'bebe','bebe@email.com','$2b$10$8KiHVvUBQwilxGbfG9Ryx.JCCA53K7xwXN5G0eQPWhCz46YoR0oS2',NULL,'2025-10-20',NULL),(36,'cece','cece@email.com','$2b$10$D1tLbQK.pjDm3h.7anB62OzWCBnBVmZI71bID4fFII.LVT6KmonGG',NULL,'2025-10-20',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-17 23:32:37
